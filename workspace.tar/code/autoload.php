<?php

require_once __DIR__ . '/utils/HtmlHelper.php';
require_once __DIR__ . '/utils/DtHelper.php';
require_once __DIR__ . '/components/DBConnection.php';
require_once __DIR__ . '/modelos/TarefaDao.php';
require_once __DIR__ . '/modelos/Tarefa.php';
