<?php /* @var $tarefa Tarefa */ ?>
<!-- Modal -->
<input type=hidden value="<?= $tarefa->id ?>" id="idTarefa">
<div class="modal fade" id="modalUpdate" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle" style="font-weight: 500 !important;">ADICIONAR NOVA TAREFA</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" id="criacaoTarefas" enctype="multipart/form-data">

                    <div class="form-group">
                        <label for="nome">Nome da Tarefa</label>
                        <input class="form-control" type=text name="nome" id="nome" placeholder="Ex.: Lavar a sala" value="<?= $tarefa->nome ?>">
                    </div>

                    <div class="form-group">
                        <label for="prioridade">Prioridade</label>
                        <select class="form-control" id="prioridade" name="prioridade" value=<?= $tarefa->prioridade ?>>
                            <option value="">Selecione uma prioridade</option>
                            <option value=1>Muito Alta</option>
                            <option value=2>Alta</option>
                            <option value=3>Média</option>
                            <option value=4>Baixa</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="prazo">Prazo</label>
                        <input type=date class="form-control" id="prazo" name="prazo" value=<?= $tarefa->prazo ?>>
                    </div>

                    <div class="form-group">
                        <label for="concluida">Concluída</label>
                        <select class="form-control" id="concluido" name="concluido">
                            <option value=0>Não concluída</option>
                            <option value=1>Concluída</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="descricao">Descrição</label>
                        <textarea class="form-control" id="descricao" rows="3" style="resize: none;" name="descricao"><?= $tarefa->descricao ?></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" id="voltar" data-dismiss="modal">Fechar</button>
                        <button type="button" id="attTarefa" class="btn btn-primary">Atualizar</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#modalUpdate").modal("show");
        $("#criacaoTarefas").validate({
            rules: {
                nome: {
                    required: true,
                },
                prioridade: {
                    required: true
                },
                prazo: {
                    required: true
                },
                concluido: {
                    required: true
                },
                descricao: {
                    required: true
                }
            }
        });

        $("#prioridade option[value=<?= $tarefa->prioridade ?>]").prop("selected", true);
        $("#concluido option[value=<?= $tarefa->concluida ?>]").prop("selected", true);
    });

    $('#attTarefa').on('click', function() {
        
        var id = $('#idTarefa').val();
        var nome = $('#nome').val();
        var prioridade = $('#prioridade').val();
        var prazo = $('#prazo').val();
        var concluido = $('#concluido').val();
        var descricao = $('#descricao').val();

        $.ajax({
            type: "POST",
            url: "/code/controladores/tarefasUpdate.php",
            data: {
                'id': id,
                'nome': nome,
                'prioridade': prioridade,
                'prazo': prazo,
                'concluido': concluido,
                'descricao': descricao
            },
            success: function(data) {
                console.log(data);
                if (data == 'errorNome') {
                    alert("Campo Nome obrigatorio");

                } else if (data == 'errorDescricao') {
                    alert("Campo descricao obrigatorio");
                } else if (data == 'errorPrazo') {
                    alert("Campo prazo obrigatório");
                } else if (data == 'errorPrioridade') {
                    alert("Campo Prioridade obrigatório");
                }
                 else {
                    $("#modalCriar").modal("hide");
                    alert("Os dados foram atualizados com sucesso!");
                    window.location.assign("/code/controladores/tarefaLista.php");
                }

            },
        });
    });

    $('#voltar').on('click', function() {
        window.location.assign("/code/controladores/tarefaLista.php");
    });
</script>