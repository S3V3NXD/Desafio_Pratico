<?php include 'modalCriar.php'; ?>
<?php include 'modalDelete.php'; ?>
<h2>Minhas Tarefas</h2>
<button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalCriar" style="margin-bottom: 8px;">
    Adicionar Tarefa
</button>

<div class="row">
    <div class="col-md-12">
        <?php
        echo HtmlHelper::table($tarefas, "tabelaTarefas", "tarefas", "id");
        ?>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#tabelaTarefas').DataTable({
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.10.12/i18n/Portuguese-Brasil.json"
            }
        });
        $("#tabelaTarefas").addClass("table-striped");
        $.fn.dataTable.moment('DD/MM/YYYY');
    });

    $(".glyphicon-trash").on('click', function() {
        $("#modalDelete").modal("show");
    });
</script>