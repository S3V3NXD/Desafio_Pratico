<?php

if (!isset($_GET['id'])) {
    die('Parametro id obrigatorio. Exemplo: ?id=5');
}


require '../autoload.php';
$dao = new TarefaDao();
$id = $_GET['id'];
$tarefa = $dao->delete($id);
header("Refresh:0; url=/code/controladores/tarefaLista.php");