<?php
require '../autoload.php';
if (isset($_GET['id'])) {

    $dao = new TarefaDao();
    $id = $_GET['id'];
    $tarefa = $dao->find($id);

    $viewname = __DIR__ . '/../views/tarefa/edits.php';
    include __DIR__ . '/../views/layouts/main.php';
}

if (isset($_POST['id'])) {

    try {
        if (empty($_POST['nome'])) {
            throw new Exception("errorNome");
        }
        if (empty($_POST['descricao'])) {
            throw new Exception("errorDescricao");
        }
        if (empty($_POST['prazo'])) {
            throw new Exception("errorPrazo");
        }
        if (empty($_POST['prioridade'])) {
            throw new Exception("errorPrioridade");
        }

        $dao = new TarefaDao();
        $id = $_POST['id'];
        $tarefa = $dao->find($id);

        $tarefa->setNomeText($_POST['nome']);
        $tarefa->setPrioridadeText($_POST['prioridade']);
        $tarefa->setConcluidaText($_POST['concluido']);
        $tarefa->setPrazoText($_POST['prazo']);
        
        $time = new DateTime('now');
        $time = $time->format('d/m/Y H:i:s');
        $tarefa->setDescricaoText($_POST['descricao'] . " Atualizado em " . $time);

        $dao->update($tarefa);
        header("Refresh:0; url=/code/controladores/tarefaLista.php");
        return $tarefa;
    } catch (Exception $e) {
        echo $e->getMessage();
    }
}