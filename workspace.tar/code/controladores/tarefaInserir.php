<?php

require '../autoload.php';
try{

    $tarefa =  new Tarefa();
    $inserirDao = new TarefaDao();

    if(empty($_POST['nome'])){
        throw new Exception("errorNome");
    }
    if(empty($_POST['descricao'])){
        throw new Exception("errorDescricao");
    }
    if(empty($_POST['prazo'])){
        throw new Exception("errorPrazo");
    }
    if(empty($_POST['prioridade'])){
        throw new Exception("errorPrioridade");
    }

    $tarefa->setNomeText($_POST['nome']);
    $tarefa->setPrioridadeText($_POST['prioridade']);
    $tarefa->setConcluidaText($_POST['concluido']);
    $tarefa->setPrazoText($_POST['prazo']);
    $tarefa->setDescricaoText($_POST['descricao']);

    $inserirDao->insert($tarefa);
    return $tarefa;


}
catch (Exception $e){
    echo $e->getMessage();
}